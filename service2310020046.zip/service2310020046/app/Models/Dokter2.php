<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Dokter2 extends Model
{
    use HasFactory;

    // 1. Beritahu Laravel nama tabelnya
    protected $table = 'dokter2';

    // ✅ 2. WAJIB: Tambahkan ini agar Edit & Hapus Berhasil
    // Sesuai screenshot migration kamu, primary key-nya adalah id_jadwal
    protected $primaryKey = 'id_jadwal';

    // 3. Kolom yang boleh diisi (Mass Assignment)
    protected $fillable = [
        'nama_dokter', 
        'hari_praktek', 
        'jam_mulai', 
        'jam_selesai'
    ];

    // ✅ 4. Ubah ke true jika di migration kamu ada $table->timestamps()
    // Di screenshot kamu ada timestamps, jadi kita set true atau hapus baris ini
    public $timestamps = true; 
}