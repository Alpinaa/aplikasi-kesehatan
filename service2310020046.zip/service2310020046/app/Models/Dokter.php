<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Dokter extends Model
{
    use HasFactory;

    // 1. Beritahu Laravel nama tabelnya
    protected $table = 'dokter';

    // ✅ 2. WAJIB: Tambahkan ini agar Edit & Hapus Berhasil
    protected $primaryKey = 'id_dokter';

    // 3. Kolom yang boleh diisi
    protected $fillable = [
        'nama_dokter', 
        'spesialis', 
        'sex', 
        'no_telp', 
        'alamat'
    ];

    // ✅ 4. Tambahkan ini jika tabel Anda tidak punya kolom created_at & updated_at
    public $timestamps = false; 
}