<?php

namespace App\Http\Controllers;

use App\Models\Dokter2;
use Illuminate\Http\Request;

class Dokter2Controller extends Controller
{
    // Menampilkan semua data jadwal dokter
    public function index()
    {
        return Dokter2::all();
    }

    // Menyimpan data jadwal dokter baru
    public function store(Request $request)
    {
        $request->validate([
            'nama_dokter'  => 'required|string',
            'hari_praktek' => 'required|string',
            'jam_mulai'    => 'required',
            'jam_selesai'  => 'required',
        ]);

        return Dokter2::create($request->all());
    }

    // Menampilkan detail satu jadwal dokter
    public function show($id)
    {
        return Dokter2::findOrFail($id);
    }

    // Mengupdate data jadwal dokter
    public function update(Request $request, $id)
    {
        $dokter2 = Dokter2::findOrFail($id);
        
        $request->validate([
            'nama_dokter'  => 'sometimes|required|string',
            'hari_praktek' => 'sometimes|required|string',
        ]);

        $dokter2->update($request->all());
        return $dokter2;
    }

    // Menghapus data jadwal dokter
    public function destroy($id)
    {
        $dokter2 = Dokter2::findOrFail($id);
        $dokter2->delete();
        return response()->json(['message' => 'Data jadwal berhasil dihapus'], 200);
    }
}