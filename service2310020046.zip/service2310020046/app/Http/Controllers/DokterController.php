<?php

namespace App\Http\Controllers;

use App\Models\Dokter;
use Illuminate\Http\Request;

class DokterController extends Controller
{
    // Menampilkan semua data dokter
    public function index()
    {
        return Dokter::all();
    }

    // Menyimpan data dokter baru
    public function store(Request $request)
    {
        $request->validate([
            'nama_dokter' => 'required|string',
            'spesialis'   => 'required|string',
            'sex'         => 'required|string', // Untuk RadioButton di Flutter
            'no_telp'     => 'required|string',
            'alamat'      => 'required|string',
        ]);

        return Dokter::create($request->all());
    }

    // Menampilkan detail satu dokter
    public function show($id)
    {
        return Dokter::findOrFail($id);
    }

    // Mengupdate data dokter
    public function update(Request $request, $id)
    {
        $dokter = Dokter::findOrFail($id);
        
        $request->validate([
            'nama_dokter' => 'sometimes|required|string',
            'no_telp'     => 'sometimes|required|string',
        ]);

        $dokter->update($request->all());
        return $dokter;
    }

    // Menghapus data dokter
    public function destroy($id)
    {
        $dokter = Dokter::findOrFail($id);
        $dokter->delete();
        return response()->json(['message' => 'Data berhasil dihapus'], 200);
    }
}