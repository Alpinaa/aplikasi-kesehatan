<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up()
    {
        Schema::create('dokter2', function (Blueprint $table) {
            // Mengikuti format gambar: menggunakan id_jadwal sebagai primary key
            $table->id('id_jadwal');
            
            // Field sesuai data dokter2 yang kamu kirim sebelumnya
            $table->string('nama_dokter');
            $table->string('hari_praktek');
            $table->time('jam_mulai');
            $table->time('jam_selesai');
            
            // Mengikuti format gambar: menambahkan timestamps (created_at & updated_at)
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down()
    {
        Schema::dropIfExists('dokters2');
    }
};