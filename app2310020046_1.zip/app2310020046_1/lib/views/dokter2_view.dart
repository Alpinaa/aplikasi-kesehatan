import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../controllers/dokter2_controller.dart';
import '../models/dokter2.dart';

class Dokter2View extends StatelessWidget {
  final Dokter2Controller controller = Get.put(Dokter2Controller());

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Jadwal Praktek Dokter"),
        backgroundColor: Colors.teal,
      ),
      body: Obx(() {
        if (controller.jadwalList.isEmpty) {
          return Center(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(Icons.event_note, size: 50, color: Colors.grey),
                SizedBox(height: 10),
                Text("Belum ada jadwal dokter."),
                ElevatedButton(
                  onPressed: () => controller.tangkapDataJadwal(),
                  child: Text("Refresh"),
                )
              ],
            ),
          );
        }

        return ListView.builder(
          itemCount: controller.jadwalList.length,
          itemBuilder: (context, index) {
            final jadwal = controller.jadwalList[index];
            return Card(
              margin: EdgeInsets.symmetric(horizontal: 10, vertical: 5),
              elevation: 3,
              child: ListTile(
                leading: CircleAvatar(
                  backgroundColor: Colors.teal,
                  child: Icon(Icons.person, color: Colors.white),
                ),
                title: Text(jadwal.namaDokter, 
                    style: TextStyle(fontWeight: FontWeight.bold)),
                subtitle: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text("Hari: ${jadwal.hariPraktek}"),
                    Text("Jam: ${jadwal.jamMulai} - ${jadwal.jamSelesai}"),
                  ],
                ),
                trailing: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    IconButton(
                      icon: Icon(Icons.edit, color: Colors.blue),
                      onPressed: () => _bukaForm(jadwal: jadwal), // EDIT DATA
                    ),
                    IconButton(
                      icon: Icon(Icons.delete, color: Colors.red),
                      onPressed: () => _konfirmasiHapus(jadwal), // HAPUS DATA
                    ),
                  ],
                ),
              ),
            );
          },
        );
      }),
      floatingActionButton: FloatingActionButton(
        onPressed: () => _bukaForm(), // TAMBAH DATA BARU
        child: Icon(Icons.add),
        backgroundColor: Colors.teal,
      ),
    );
  }

  // MODAL FORM UNTUK TAMBAH & EDIT
  void _bukaForm({Dokter2? jadwal}) {
    bool isEdit = jadwal != null;
    
    // Controller input
    final namaController = TextEditingController(text: isEdit ? jadwal.namaDokter : "");
    final hariController = TextEditingController(text: isEdit ? jadwal.hariPraktek : "");
    final mulaiController = TextEditingController(text: isEdit ? jadwal.jamMulai : "");
    final selesaiController = TextEditingController(text: isEdit ? jadwal.jamSelesai : "");

    Get.bottomSheet(
      Container(
        padding: EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
        ),
        child: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(isEdit ? "Edit Jadwal Dokter" : "Tambah Jadwal Baru",
                  style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
              SizedBox(height: 10),
              TextField(controller: namaController, decoration: InputDecoration(labelText: "Nama Dokter")),
              TextField(controller: hariController, decoration: InputDecoration(labelText: "Hari")),
              Row(
                children: [
                  Expanded(child: TextField(controller: mulaiController, decoration: InputDecoration(labelText: "Jam Mulai"))),
                  SizedBox(width: 10),
                  Expanded(child: TextField(controller: selesaiController, decoration: InputDecoration(labelText: "Jam Selesai"))),
                ],
              ),
              SizedBox(height: 20),
              ElevatedButton(
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.teal,
                  minimumSize: Size(double.infinity, 50),
                ),
                onPressed: () {
                  // Buat objek Dokter2 baru dari inputan
                  Dokter2 dataBaru = Dokter2(
                    idJadwal: isEdit ? jadwal.idJadwal : null,
                    namaDokter: namaController.text,
                    hariPraktek: hariController.text,
                    jamMulai: mulaiController.text,
                    jamSelesai: selesaiController.text,
                  );

                  if (isEdit) {
                    controller.updateJadwal(jadwal.idJadwal!, dataBaru);
                  } else {
                    controller.addJadwal(dataBaru);
                  }
                },
                child: Text(isEdit ? "Simpan Perubahan" : "Simpan Data", 
                    style: TextStyle(color: Colors.white)),
              ),
              SizedBox(height: 20),
            ],
          ),
        ),
      ),
      isScrollControlled: true,
    );
  }

  void _konfirmasiHapus(Dokter2 jadwal) {
    Get.defaultDialog(
      title: "Hapus Data",
      middleText: "Yakin ingin menghapus jadwal dr. ${jadwal.namaDokter}?",
      textConfirm: "Ya, Hapus",
      textCancel: "Batal",
      confirmTextColor: Colors.white,
      onConfirm: () {
        controller.deleteJadwal(jadwal.idJadwal!);
        Get.back();
      },
    );
  }
}