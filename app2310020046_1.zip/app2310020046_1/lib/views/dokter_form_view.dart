import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../controllers/dokter_controller.dart';
import '../models/dokter.dart';

class DokterFormView extends StatefulWidget {
  final Dokter? dokter; // Jika ada isinya, berarti mode EDIT
  const DokterFormView({super.key, this.dokter});

  @override
  State<DokterFormView> createState() => _DokterFormViewState();
}

class _DokterFormViewState extends State<DokterFormView> {
  final controller = Get.find<DokterController>();
  
  // Controller untuk input teks
  final namaC = TextEditingController();
  final spesialisC = TextEditingController();
  final telpC = TextEditingController();
  final alamatC = TextEditingController();
  
  // Variabel untuk RadioButton
  String _sex = "L"; 

  @override
  void initState() {
    super.initState();
    // Jika mode EDIT, isi field dengan data yang sudah ada
    if (widget.dokter != null) {
      namaC.text = widget.dokter!.namaDokter;
      spesialisC.text = widget.dokter!.spesialis;
      telpC.text = widget.dokter!.noTelp;
      alamatC.text = widget.dokter!.alamat;
      _sex = widget.dokter!.sex;
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(widget.dokter == null ? "Tambah Dokter" : "Edit Dokter")),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: ListView(
          children: [
            TextField(controller: namaC, decoration: const InputDecoration(labelText: "Nama Dokter")),
            TextField(controller: spesialisC, decoration: const InputDecoration(labelText: "Spesialis")),
            const SizedBox(height: 20),
            const Text("Jenis Kelamin:"),
            
            // ✅ IMPLEMENTASI RADIOBUTTON
            RadioListTile(
              title: const Text("Laki-laki"),
              value: "L",
              groupValue: _sex,
              onChanged: (val) => setState(() => _sex = val.toString()),
            ),
            RadioListTile(
              title: const Text("Perempuan"),
              value: "P",
              groupValue: _sex,
              onChanged: (val) => setState(() => _sex = val.toString()),
            ),
            
            TextField(controller: telpC, decoration: const InputDecoration(labelText: "No Telp")),
            TextField(controller: alamatC, decoration: const InputDecoration(labelText: "Alamat")),
            const SizedBox(height: 30),
            ElevatedButton(
              onPressed: () {
                final d = Dokter(
                  idDokter: widget.dokter?.idDokter,
                  namaDokter: namaC.text,
                  spesialis: spesialisC.text,
                  noTelp: telpC.text,
                  alamat: alamatC.text,
                  sex: _sex,
                );

                if (widget.dokter == null) {
                  controller.addDokter(d);
                } else {
                  // ✅ MEMANGGIL FUNGSI UPDATE DI CONTROLLER
                  controller.updateDokter(widget.dokter!.idDokter!, d);
                }
                Get.back(); // Kembali ke halaman daftar setelah simpan
              },
              child: const Text("Simpan Perubahan"),
            )
          ],
        ),
      ),
    );
  }
}