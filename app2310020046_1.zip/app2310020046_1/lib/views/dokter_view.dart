import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../controllers/dokter_controller.dart';
import 'dokter_form_view.dart'; // ✅ Pastikan mengimpor halaman form

class DokterView extends StatelessWidget {
  DokterView({super.key});

  final DokterController controller = Get.put(DokterController());

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Data Dokter"),
        centerTitle: true,
      ),
      body: Column(
        children: [
          Expanded(
            child: Obx(() {
              if (controller.dokterList.isEmpty) {
                return const Center(child: Text("Tidak ada data dokter"));
              }

              return ListView.builder(
                itemCount: controller.dokterList.length,
                itemBuilder: (context, index) {
                  final dokter = controller.dokterList[index];
                  return Card(
                    margin: const EdgeInsets.all(10),
                    elevation: 5,
                    child: Padding(
                      padding: const EdgeInsets.all(15.0),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            dokter.namaDokter, 
                            style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 18),
                          ),
                          const SizedBox(height: 5),
                          Text("Spesialis: ${dokter.spesialis}"),
                          Text("No Telp: ${dokter.noTelp}"),
                          Text("Alamat: ${dokter.alamat}"),
                          Text("Jenis Kelamin: ${dokter.sex == 'L' ? 'Laki-Laki' : 'Perempuan'}"),
                          const SizedBox(height: 10),
                          OverflowBar(
                            alignment: MainAxisAlignment.end,
                            children: <Widget>[
                              // ✅ TOMBOL EDIT BARU
                              TextButton(
                                child: const Text('Edit', style: TextStyle(color: Colors.blue)),
                                onPressed: () {
                                  // Navigasi ke form dengan membawa data objek dokter
                                  Get.to(() => DokterFormView(dokter: dokter));
                                },
                              ),
                              TextButton(
                                child: const Text('Hapus', style: TextStyle(color: Colors.red)),
                                onPressed: () {
                                  controller.deleteDokter(dokter.idDokter!);
                                },
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                  );
                },
              );
            }),
          ),
        ],
      ),
      // Tambahkan FloatingActionButton untuk Tambah Data Baru
      floatingActionButton: FloatingActionButton(
        onPressed: () => Get.to(() => const DokterFormView()),
        child: const Icon(Icons.add),
      ),
    );
  }
}