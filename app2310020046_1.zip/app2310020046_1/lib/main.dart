import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'views/dokter_view.dart'; 

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    // Menggunakan GetMaterialApp karena kita memakai GetX untuk Controller
    return GetMaterialApp(
      title: 'App2310020046_1', // Nama aplikasi sesuai NPM Anda
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        // Warna indigo memberikan tampilan yang profesional untuk aplikasi klinik
        primarySwatch: Colors.indigo,
        useMaterial3: true,
      ),
      // ✅ Mengarahkan halaman utama ke DokterView agar data dari Laravel muncul
      home: DokterView(), 
    );
  }
}