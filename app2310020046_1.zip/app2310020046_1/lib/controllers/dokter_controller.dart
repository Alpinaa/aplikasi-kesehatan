import 'package:get/get.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import '../models/dokter.dart';

class DokterController extends GetxController {
  var dokterList = <Dokter>[].obs;
  final String apiUrl = 'http://127.0.0.1:8000/api/dokter';

  @override
  void onInit() {
    super.onInit();
    tangkapDataDokter();
  }

  Future<void> tangkapDataDokter() async {
    try {
      final response = await http.get(Uri.parse(apiUrl));
      if (response.statusCode == 200) {
        List<dynamic> data = json.decode(response.body);
        dokterList.value = data.map((item) => Dokter.fromJson(item)).toList();
      }
    } catch (e) {
      print('Error ambil data: $e');
    }
  }

  Future<void> addDokter(Dokter dokter) async {
    try {
      final response = await http.post(
        Uri.parse(apiUrl),
        headers: {"Content-Type": "application/json"},
        body: json.encode(dokter.toJson()),
      );
      if (response.statusCode == 201) {
        tangkapDataDokter();
        Get.back();
        Get.snackbar("Sukses", "Data berhasil ditambahkan");
      }
    } catch (e) {
      Get.snackbar("Error", "Gagal simpan: $e");
    }
  }

  // Edit pada fungsi Update agar lebih teliti mengirim ID
  Future<void> updateDokter(int id, Dokter dokter) async {
    try {
      // Kita coba kirim ID lewat URL
      final response = await http.put(
        Uri.parse('$apiUrl/$id'), 
        headers: {"Content-Type": "application/json"},
        body: json.encode(dokter.toJson()),
      );

      if (response.statusCode == 200) {
        tangkapDataDokter();
        Get.back();
        Get.snackbar("Sukses", "Data berhasil dirubah");
      } else {
        // Jika gagal, tampilkan pesan error dari server untuk memudahkan debug
        Get.snackbar("Gagal", "Server merespon: ${response.statusCode}");
        print("Detail Error Update: ${response.body}");
      }
    } catch (e) {
      Get.snackbar("Error", "Koneksi bermasalah: $e");
    }
  }

  // Edit pada fungsi Delete untuk menangani masalah ID di server
  Future<void> deleteDokter(int id) async {
    try {
      // Mengirim perintah delete ke URL /api/dokter/{id}
      final response = await http.delete(Uri.parse('$apiUrl/$id'));

      print("Status Hapus: ${response.statusCode}");

      if (response.statusCode == 200 || response.statusCode == 204) {
        // Langsung hapus di list lokal supaya UI berubah seketika
        dokterList.removeWhere((d) => d.idDokter == id);
        Get.snackbar("Sukses", "Data berhasil dihapus");
      } else {
        // Jika server menolak, kemungkinan besar karena kolom id_dokter di Backend belum diset
        Get.snackbar("Gagal", "Gagal hapus (Error: ${response.statusCode})");
        print("Pesan Server: ${response.body}");
      }
    } catch (e) {
      print('Error hapus: $e');
      Get.snackbar("Error", "Koneksi ke server terputus");
    }
  }
}