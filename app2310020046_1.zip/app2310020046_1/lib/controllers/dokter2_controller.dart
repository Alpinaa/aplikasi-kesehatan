import 'package:get/get.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
// PERBAIKAN: Nama file disesuaikan dengan screenshot kamu (dokter2.dart)
import '../models/dokter2.dart'; 

class Dokter2Controller extends GetxController {
  var jadwalList = <Dokter2>[].obs;
  
  // Gunakan 10.0.2.2 untuk emulator, atau IP Laptop untuk HP Fisik
  final String apiUrl = 'http://127.0.0.1:8000/api/dokter2';

  @override
  void onInit() {
    super.onInit();
    tangkapDataJadwal();
  }

  Future<void> tangkapDataJadwal() async {
    try {
      final response = await http.get(Uri.parse(apiUrl));
      if (response.statusCode == 200) {
        List<dynamic> data = json.decode(response.body);
        jadwalList.value = data.map((item) => Dokter2.fromJson(item)).toList();
      }
    } catch (e) {
      print('Error ambil data: $e');
    }
  }

  Future<void> addJadwal(Dokter2 jadwal) async {
    try {
      final response = await http.post(
        Uri.parse(apiUrl),
        headers: {"Content-Type": "application/json"},
        body: json.encode(jadwal.toJson()),
      );
      if (response.statusCode == 201) {
        tangkapDataJadwal();
        Get.back();
        Get.snackbar("Sukses", "Jadwal berhasil ditambahkan");
      }
    } catch (e) {
      Get.snackbar("Error", "Gagal simpan: $e");
    }
  }

  Future<void> updateJadwal(int id, Dokter2 jadwal) async {
    try {
      final response = await http.put(
        Uri.parse('$apiUrl/$id'), 
        headers: {"Content-Type": "application/json"},
        body: json.encode(jadwal.toJson()),
      );

      if (response.statusCode == 200) {
        tangkapDataJadwal();
        Get.back();
        Get.snackbar("Sukses", "Jadwal berhasil dirubah");
      }
    } catch (e) {
      Get.snackbar("Error", "Koneksi bermasalah: $e");
    }
  }

  Future<void> deleteJadwal(int id) async {
    try {
      final response = await http.delete(Uri.parse('$apiUrl/$id'));
      if (response.statusCode == 200 || response.statusCode == 204) {
        // idJadwal harus sama dengan yang ada di class Dokter2
        jadwalList.removeWhere((d) => d.idJadwal == id);
        Get.snackbar("Sukses", "Jadwal berhasil dihapus");
      }
    } catch (e) {
      Get.snackbar("Error", "Koneksi ke server terputus");
    }
  }
}