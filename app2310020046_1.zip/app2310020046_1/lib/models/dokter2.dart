class Dokter2 {
  final int? idJadwal; 
  final String namaDokter;
  final String hariPraktek;
  final String jamMulai; 
  final String jamSelesai;

  Dokter2({
    this.idJadwal,
    required this.namaDokter,
    required this.hariPraktek,
    required this.jamMulai,
    required this.jamSelesai,
  });

  factory Dokter2.fromJson(Map<String, dynamic> json) {
    return Dokter2(
      idJadwal: json['id_jadwal'] as int?, 
      namaDokter: json['nama_dokter'] ?? "",
      hariPraktek: json['hari_praktek'] ?? "",
      jamMulai: json['jam_mulai'] ?? "",
      jamSelesai: json['jam_selesai'] ?? "",
    );
  }

  Map<String, dynamic> toJson() {
    return {
      if (idJadwal != null) 'id_jadwal': idJadwal,
      'nama_dokter': namaDokter,
      'hari_praktek': hariPraktek,
      'jam_mulai': jamMulai,
      'jam_selesai': jamSelesai,
    };
  }
}