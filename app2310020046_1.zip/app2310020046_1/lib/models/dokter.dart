class Dokter {
  final int? idDokter; 
  final String namaDokter;
  final String spesialis;
  final String sex; 
  final String noTelp;
  final String alamat;

  Dokter({
    this.idDokter,
    required this.namaDokter,
    required this.spesialis,
    required this.sex,
    required this.noTelp,
    required this.alamat,
  });

  factory Dokter.fromJson(Map<String, dynamic> json) {
    return Dokter(
      // Menggunakan casting 'as int?' untuk memastikan tipe data aman
      idDokter: json['id_dokter'] as int?, 
      namaDokter: json['nama_dokter'] ?? "",
      spesialis: json['spesialis'] ?? "",
      sex: json['sex'] ?? "L",
      noTelp: json['no_telp'] ?? "",
      alamat: json['alamat'] ?? "",
    );
  }

  Map<String, dynamic> toJson() {
    return {
      // ✅ Pastikan id_dokter disertakan jika tidak null agar Laravel tidak bingung
      if (idDokter != null) 'id_dokter': idDokter,
      'nama_dokter': namaDokter,
      'spesialis': spesialis,
      'sex': sex,
      'no_telp': noTelp,
      'alamat': alamat,
    };
  }
}