package com.example.app2310020046_1

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
